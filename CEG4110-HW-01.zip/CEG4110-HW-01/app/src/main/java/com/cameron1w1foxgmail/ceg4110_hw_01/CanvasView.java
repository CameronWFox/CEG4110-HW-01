package com.cameron1w1foxgmail.ceg4110_hw_01;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class CanvasView extends View
{

    public int width;
    public int height;

    private float myX;
    private float myY;

    public Bitmap myBitmap;
    public Canvas myCanvas;
    Context context;

    private static final float TOLERANCE = 5;

    private Path myPath;
    public Paint myPaintBrush;

    public CanvasView(Context context, AttributeSet attributeSet)
    {
        super(context, attributeSet);
        this.context = context;

        myPath = new Path();
        myPaintBrush = new Paint();

        myPaintBrush.setAntiAlias(true);
        myPaintBrush.setColor(Color.BLACK);
        myPaintBrush.setStyle(Paint.Style.STROKE);
        myPaintBrush.setStrokeJoin(Paint.Join.ROUND);
        myPaintBrush.setStrokeCap(Paint.Cap.ROUND);
        myPaintBrush.setStrokeWidth(4f);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        myBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        myCanvas = new Canvas(myBitmap);
    }

    // Method for drawing on the canvas
    @Override
    protected void onDraw(Canvas canvas)
    {
        super.onDraw(canvas);

        canvas.drawPath(myPath, myPaintBrush);
    }

    // When the user starts to paint and sets there finger on the screen
    private void startTouch(float x, float y)
    {
        myPath.moveTo(x, y);
        myX = x;
        myY = y;
    }

    // When the user moves there finger across the screen
    private void moveTouch(float x, float y)
    {
        float dX = Math.abs(x - myX);
        float dY = Math.abs(y - myY);

        if (dX >= TOLERANCE || dY >= TOLERANCE)
        {
            myPath.quadTo(myX, myY, (x + myX) / 2, (y + myY) / 2);
            myX = x;
            myY = y;
        }
    }

    // Clearing the canvas drawing
    public void clearCanvas()
    {
        myPath.reset();
        invalidate();
    }

    // When you pick up your finger from drawing
    private void upTouch()
    {
        myPath.lineTo(myX, myY);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        float x = event.getX();
        float y = event.getY();

        switch(event.getAction())
        {
            case MotionEvent.ACTION_DOWN:
                startTouch(x, y);
                invalidate();
                break;
            case MotionEvent.ACTION_MOVE:
                moveTouch(x, y);
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
                upTouch();
                invalidate();
                break;
        }
        return true;
    }
}
