package com.cameron1w1foxgmail.ceg4110_hw_01;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Random;

import static android.os.Environment.DIRECTORY_PICTURES;

public class CanvasMainActivity extends AppCompatActivity
{
    // Part 2 of Assignment
    private Button button3; // Clear Canvas Button
    private Button button4; // Change Paint Color for Canvas Button
    private Button button5; // Allow the user to save there canvas drawings as png files
    private Button button6; // Back to previous Activity
    private CanvasView canvasView; // Canvas for drawing

    private boolean successCanvasSaved = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_canvas_main);

        canvasView = (CanvasView) findViewById(R.id.canvas);

        button3 = findViewById(R.id.clearCanvas);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                clearCanvas(v);
            }
        });

        button4 = findViewById(R.id.paintBrushColor);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                changePaintColor(v);
            }
        });

        button5 = findViewById(R.id.saveDrawing);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                saveDrawingPNG(v);

                if (successCanvasSaved)
                {
                    Toast.makeText(CanvasMainActivity.this, "The canvas was Saved", Toast.LENGTH_SHORT).show(); // Canvas Image was saved
                }
                else
                {
                    Toast.makeText(CanvasMainActivity.this, "The canvas was not Saved", Toast.LENGTH_SHORT).show(); // Canvas Image was not saved
                }
            }
        });

        button6 = findViewById(R.id.backButton);
        button6.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                previousActivity(v);
            }
        });
    }

    public void clearCanvas(View view)
    {
        canvasView.clearCanvas();
    }

    public void changePaintColor(View view)
    {
        Random paintColorGen = new Random();
        int a = paintColorGen.nextInt(255);
        int r = paintColorGen.nextInt(255);
        int g = paintColorGen.nextInt(255);
        int b = paintColorGen.nextInt(255);
        int paintBrushColor = android.graphics.Color.argb(a, r, g, b);

        canvasView.myPaintBrush.setColor(paintBrushColor);
        button4.setBackgroundColor(paintBrushColor);
    }

    public void previousActivity(View view)
    {
        startActivity(new Intent(CanvasMainActivity.this, MainActivity.class));
    }

    public void saveDrawingPNG(View view)
    {
        Intent imageSaveIntent = new Intent();
        String canvasName = canvasView.toString();

        File pictureDictionary = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        File canvasFile = new File(pictureDictionary, canvasName);

        successCanvasSaved = true;
    }
}
