package com.cameron1w1foxgmail.ceg4110_hw_01;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity
{

    // Part 1 of Assignment
    Button button1; // Text Color Change Button
    EditText editText; // Text box to put in the color text
    TextView textView; // Used to show the color HTML data

    Button button2; // Travel to other activity


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.textColor);
        editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                editTextOnClick(v);
            }
        });

        textView = findViewById(R.id.colorHTMLCode);

        button1 = findViewById(R.id.changeTextColor);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeTextColor(v);
            }
        });

        button2 = findViewById(R.id.goToCanvas);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                nextActivity(v);
            }
        });
    }

    // This method will change the text color of whatever color the user types when you press the button
    public void changeTextColor(View view)
    {
        Random textColorGen = new Random();
        int a = textColorGen.nextInt(255);
        int r = textColorGen.nextInt(255);
        int g = textColorGen.nextInt(255);
        int b = textColorGen.nextInt(255);
        int textColor = android.graphics.Color.argb(a, r, g, b);

        int newTextColor = textColor / 2^8; // Getting ready to convert to hex
        String hexTextColor = Integer.toHexString(newTextColor); // Convert the text color int into a Hex String

        editText.setTextColor(textColor); // The color that is generated
        textView.setText("Color: "+r+"r, "+g+"g, "+b+"b, #"+hexTextColor);
    }

    public void editTextOnClick(View view)
    {
        editText.getText().clear(); // clears the current text in the editText object
    }

    public void nextActivity(View view)
    {
        startActivity(new Intent(MainActivity.this, CanvasMainActivity.class));
    }
}
